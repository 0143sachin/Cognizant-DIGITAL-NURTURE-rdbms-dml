insert into Payments(PAYMENT_ID,Ticket_ID,BD_ID,DISCOUNT_ID) values('P1','T3',1005,'D3');
insert into Payments(PAYMENT_ID,Ticket_ID,BD_ID,DISCOUNT_ID) values('P2','T2',1004,'D5');