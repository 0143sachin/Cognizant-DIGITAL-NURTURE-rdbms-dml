insert into tickets(Ticket_id,Schedule_id,User_id,No_seats) VALUES('T1','S5',1,2);
insert into tickets(Ticket_id,Schedule_id,User_id,No_seats) VALUES('T2','S2',5,1);